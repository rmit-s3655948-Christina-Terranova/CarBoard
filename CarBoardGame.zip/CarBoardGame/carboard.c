/******************************************************************************
** Student name: 	Christina Terranova
** Student number: 	s3655948
** Course: 			Advanced Programming Techniques - S1 2018
******************************************************************************/

#include "carboard.h"

int main(void)
{
    menu();

    printf("Good bye! \n\n");

    return EXIT_SUCCESS;
}

void showStudentInformation()
{
    printf(" Name: " STUDENT_NAME "\n No: " STUDENT_ID "\n Email: " STUDENT_EMAIL "\n");
}

void menu(){

    char menuNo[BUFFSIZE];

    printf("Welcome to Car Board\n --------------------\n 1. Play game\n 2. Show student’s information\n "
                   "3. Quit\n\n Please enter your choice: ");
    fgets(menuNo, sizeof(menuNo), stdin);

    if( menuNo[strlen(menuNo) - 1] != '\n') {
        readRestOfLine();
    }

    menuNo[strlen(menuNo) - 1] = '\0';

    if (strcmp(menuNo,MENU_OPTION_1) == 0) {
        printf("You can use the following commands to play the game:\n"
                       "load <g>\n"
                       "g: number of the game board to load\n"
                       "init <x>,<y>,<direction>\n"
                       "x: horizontal position of the car on the board (between 0 & 9)\n"
                       "y: vertical position of the car on the board (between 0 & 9)\n"
                       "direction: direction of the car’s movement (north, east, south, west)\n"
                       "forward (or f)\n"
                       "turn_left (or l)\n"
                       "turn_right (or r)\n"
                       "quit\n\n");

    playGame();

   } else if (strcmp(menuNo,MENU_OPTION_2) == 0) {
       showStudentInformation();
        menu();
   } else if (strcmp(menuNo,MENU_OPTION_3) == 0) {
       exit(0);
   }
   else{
       menu();
   }
}
