/******************************************************************************
** Student name: 	Christina Terranova
** Student number: 	s3655948
** Course: 			Advanced Programming Techniques - S1 2018
******************************************************************************/

#include "game.h"

/**gets command input by user **/
char* getUserInput(char command[], int lengthCommand){

    fgets(command, lengthCommand ,stdin);
    if(command[strlen(command) - 1] != '\n') {
        readRestOfLine();
    }

    command[strlen(command) - 1] = '\0';

    return command;
}

/** check if x and y position are ints**/
enum boolean isNumeric(char* positionTok, char* endOfPos){
    if(positionTok == endOfPos || *endOfPos != '\0'){
        return FALSE;
    }
    else{
        return TRUE;
    }
}

/** gets the player's direction dependent on user's input**/
Direction getDirection(char* direction){

    Direction playerDirection;

    if(strcmp(direction, DIRECTION_NORTH) == 0){
        playerDirection = NORTH;
    }
    if(strcmp(direction, DIRECTION_SOUTH) == 0){
        playerDirection = SOUTH;
    }
    if(strcmp(direction, DIRECTION_EAST) == 0){
        playerDirection = EAST;
    }
    if(strcmp(direction, DIRECTION_WEST) == 0){
        playerDirection = WEST;
    }

    return playerDirection;
}


void displayEmptyBoard(Cell board[BOARD_HEIGHT][BOARD_WIDTH]){
    initialiseBoard(board);
    displayBoard(board, NULL);
}

void loadAndDisplayBoard(Cell board[BOARD_HEIGHT][BOARD_WIDTH]){

    char* loadCommand;
    char command[BUFFSIZE];

    printf("At this stage of the program, only two commands are acceptable:\n"
                   "load <g>\n"
                   "quit\n");

    loadCommand = getUserInput(command, sizeof(command));

    if(strcmp(loadCommand, COMMAND_QUIT) == 0){
        menu();
    }
    else if(strcmp(loadCommand, COMMAND_LOAD LOAD1) == 0){
        loadBoard(board, BOARD_1);
        displayBoard(board, NULL);
    }
    else if(strcmp(loadCommand, COMMAND_LOAD LOAD2) == 0) {
        loadBoard(board, BOARD_2);
        displayBoard(board, NULL);
    }
    else{
        printf("Invalid input.\n");
        loadAndDisplayBoard(board);
    }

}

void displayBoardWithPlayer(Player * player, Cell board[BOARD_HEIGHT][BOARD_WIDTH]){

    char *initCommand, *direction, *y , *x, *endOfX, *endOfY;
    char command[BUFFSIZE];
    int xVal, yVal;
    Position pos;
    Direction playerDirection;

    printf("At this stage of the program, only three commands are acceptable:\nload <g>\ninit <x>,<y>,<direction>\nquit\n");
    initCommand = getUserInput(command, sizeof(command));

    if(strcmp(initCommand, COMMAND_QUIT) == 0){
        menu();
    }
    else if(strcmp(initCommand, COMMAND_LOAD LOAD1) == 0){
        loadBoard(board, BOARD_1);
        displayBoard(board, NULL);
        displayBoardWithPlayer(player,board);
    }
    else if(strcmp(initCommand, COMMAND_LOAD LOAD2) == 0) {
        loadBoard(board, BOARD_2);
        displayBoard(board, NULL);
        displayBoardWithPlayer(player,board);
    }
    /** checks for valid length of command and valid position of each delimiter in the command */
    else if((strlen(initCommand) == LEN_INIT || strlen(initCommand) == LEN_INIT2) && initCommand[DELIM1_POS] == CHARDELIM &&
            initCommand[DELIM2_POS] == CHARDELIM2 && initCommand[DELIM3_POS] == CHARDELIM2){
        strtok(initCommand, DELIM);  /** removes 'INIT ' */
        x = strtok(NULL, DELIM2);   /** gets x position and converts to int*/
        xVal = strtol(x, &endOfX, BASE);
        y = strtok(NULL, DELIM2); /** gets y position and converts to int*/
        yVal = strtol(y, &endOfY, BASE);
        direction = strtok(NULL, DELIM2); /** gets direction */

        /**Checks that x and y player position entered aren't out of bounds or on a blocked cell.
          Also checks valid direction was entered**/
        if(xVal >= MIN_BOARD && xVal <= MAX_BOARD && yVal >= MIN_BOARD && yVal <= MAX_BOARD && isNumeric(x, endOfX)
           && isNumeric(y, endOfY) && (strcmp(direction, DIRECTION_NORTH) == 0 || strcmp(direction, DIRECTION_SOUTH) == 0 ||
            strcmp(direction, DIRECTION_EAST) == 0 || strcmp(direction, DIRECTION_WEST) == 0) && board[yVal][xVal] == EMPTY){
            pos.x = xVal;
            pos.y = yVal;
            playerDirection = getDirection(direction);
            initialisePlayer(player, &pos, playerDirection);
            placePlayer(board, pos);
            displayBoard(board, player);
        }
        else {
            if (board[yVal][xVal] == BLOCKED) {
                printf("Can't place player on blocked cell.\n");
            }
            else {
                printf("Invalid input.\n");
            }
            displayBoardWithPlayer(player,board);
        }
    }
    else{
        printf("Invalid input.\n");
        displayBoardWithPlayer(player,board);
    }
}


void movePlayer(Player * player, Cell board[BOARD_HEIGHT][BOARD_WIDTH] ){

    char* moveCommand;
    char command[BUFFSIZE];

    printf("At this stage of the program, only four commands are acceptable:\n"
                   "forward(or f)\n"
                   "turn_left (or l)\n"
                   "turn_right (or r)\n"
                   "quit\n");


    moveCommand = getUserInput(command, sizeof(command));

    if(strcmp(moveCommand, COMMAND_TURN_LEFT) == 0 || strcmp(moveCommand, COMMAND_TURN_LEFT_SHORTCUT) == 0 ){
        turnDirection(player, TURN_LEFT);
        displayBoard(board,player);
        movePlayer(player,board);
    }
    else if(strcmp(moveCommand, COMMAND_TURN_RIGHT) == 0 || strcmp(moveCommand, COMMAND_TURN_RIGHT_SHORTCUT) == 0){
        turnDirection(player, TURN_RIGHT);
        displayBoard(board,player);
        movePlayer(player,board);
    }
    else if(strcmp(moveCommand,COMMAND_FORWARD) == 0 || strcmp(moveCommand,COMMAND_FORWARD_SHORTCUT) == 0){
        movePlayerForward(board, player);
        displayBoard(board,player);
        movePlayer(player,board);

    }
    else if(strcmp(moveCommand, COMMAND_QUIT) == 0){
        printf("Total player moves: %d\n", player->moves );
        menu();
    }
    else{
        printf("Invalid input.\n");
        movePlayer(player,board);
    }

}


void playGame()
{

    Cell board[BOARD_HEIGHT][BOARD_WIDTH];
    Player player[2];

    /** display initialised empty board */
    displayEmptyBoard(board);

    /** load and display board 1 or 2 */
    loadAndDisplayBoard(board);

    /**load and display board with player */
    displayBoardWithPlayer(player, board);

    /**moving player around board **/
    movePlayer(player,board);

}
