/******************************************************************************
** Student name: 	Christina Terranova
** Student number: 	s3655948
** Course: 			Advanced Programming Techniques - S1 2018
******************************************************************************/

#include "player.h"

void initialisePlayer(Player * player, Position * position, Direction direction)
{
    /** initialise position **/
    player->position.x = position->x;
    player->position.y = position->y;

    /** initialise direction */
    if(direction == NORTH){
        player->direction = NORTH;
    }
    if(direction == EAST){
        player->direction = EAST;
    }
    if(direction == SOUTH){
        player->direction = SOUTH;
    }
    if(direction == WEST){
        player->direction = WEST;
    }

    /**initialise moves to 0 **/
    player->moves = 0;

}

void turnDirection(Player * player, TurnDirection turnDirection)
{
    if(turnDirection == TURN_LEFT){
        if(player->direction == NORTH){
            player->direction = WEST;
        }
        else if(player->direction == WEST){
            player->direction = SOUTH;
        }
        else if(player->direction == SOUTH){
            player->direction = EAST;
        }
        else if(player->direction == EAST){
            player->direction = NORTH;
        }
    }

    if(turnDirection == TURN_RIGHT){
        if(player->direction == NORTH){
            player->direction = EAST;
        }
        else if(player->direction == EAST){
            player->direction = SOUTH;
        }
        else if(player->direction == SOUTH){
            player->direction = WEST;
        }
        else if(player->direction == WEST){
            player->direction = NORTH;
        }
    }

}

Position getNextForwardPosition(const Player * player)
{
    Position position;

        if (player->direction == NORTH) {
            position.y = (player->position.y) - 1;
            position.x = (player->position.x);
        } else if (player->direction == SOUTH) {
            position.y = (player->position.y) + 1;
            position.x = (player->position.x);
        } else if (player->direction == EAST) {
            position.x = (player->position.x) + 1;
            position.y = (player->position.y);
        } else if (player->direction == WEST) {
            position.x = (player->position.x) - 1 ;
            position.y = (player->position.y);
        }

    return position;

}

void updatePosition(Player * player, Position position)
{
    player->position.y = position.y;
    player->position.x = position.x;

    player->moves = player->moves + 1;
}

void displayDirection(Direction direction)
{
    if(direction == NORTH){
        printf(DIRECTION_ARROW_OUTPUT_NORTH "|");
    }
    if(direction == EAST){
        printf(DIRECTION_ARROW_OUTPUT_EAST "|");
    }
    if(direction == SOUTH){
        printf(DIRECTION_ARROW_OUTPUT_SOUTH "|");
    }
    if(direction == WEST){
        printf(DIRECTION_ARROW_OUTPUT_WEST "|");
    }
}
